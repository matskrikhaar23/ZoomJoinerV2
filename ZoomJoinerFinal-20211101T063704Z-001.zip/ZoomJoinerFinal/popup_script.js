chrome.runtime.sendMessage({            //sends a message to whichever catches the message first
    message: "get_name"
}, response => {
    if (response.message = 'sucess') {
        document.querySelector('div').innerHTML = "Welcome To ZoomJoiner";
    }
})
